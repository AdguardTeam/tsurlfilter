import { CosmeticRule } from './cosmetic-rule';
import { NetworkRule } from './network-rule';
import { RULE_INDEX_NONE, type IRule } from './rule';
import { findCosmeticRuleMarker } from './cosmetic-rule-marker';
import { HostRule } from './host-rule';
import { logger } from '../utils/logger';
import { getErrorMessage } from '../common/error';

/**
 * Rule builder class
 */
export class RuleFactory {
    /**
     * Creates rule of suitable class from text string
     * It returns null if the line is empty or if it is a comment
     *
     * TODO: Pack `ignore*` parameters and `silent` into one object with flags.
     *
     * @param text rule string
     * @param filterListId list id
     * @param ruleIndex line start index in the source filter list; it will be used to find the original rule text
     * in the filtering log when a rule is applied. Default value is {@link RULE_INDEX_NONE} which means that
     * the rule does not have source index
     * @param ignoreNetwork do not create network rules
     * @param ignoreCosmetic do not create cosmetic rules
     * @param ignoreHost do not create host rules
     * @param silent Log the error for `true`, otherwise throw an exception on
     * a rule creation
     *
     * @throws Error when `silent` flag is passed as false on rule creation error.
     *
     * @return IRule object or null
     */
    public static createRule(
        text: string,
        filterListId: number,
        ruleIndex = RULE_INDEX_NONE,
        ignoreNetwork = false,
        ignoreCosmetic = false,
        ignoreHost = true,
        silent = true,
    ): IRule | null {
        const line = text.trim();

        if (!line || RuleFactory.isComment(line)) {
            return null;
        }

        if (RuleFactory.isShort(line)) {
            logger.info(`The rule is too short: ${line}`);
        }

        try {
            if (RuleFactory.isCosmetic(line)) {
                if (ignoreCosmetic) {
                    return null;
                }

                return new CosmeticRule(line, filterListId, ruleIndex);
            }

            if (!ignoreHost) {
                const hostRule = RuleFactory.createHostRule(line, filterListId, ruleIndex);
                if (hostRule) {
                    return hostRule;
                }
            }

            if (!ignoreNetwork) {
                return new NetworkRule(line, filterListId, ruleIndex);
            }
        } catch (e) {
            const msg = `"${getErrorMessage(e)}" in the rule: "${line}"`;
            if (silent) {
                logger.info(`Error: ${msg}`);
            } else {
                throw new Error(msg);
            }
        }

        return null;
    }

    /**
     * Creates host rule from text
     *
     * @param ruleText Rule text
     * @param filterListId Filter list id
     * @param ruleIndex line start index in the source filter list; it will be used to find the original rule text
     * in the filtering log when a rule is applied. Default value is {@link RULE_INDEX_NONE} which means that
     * the rule does not have source index
     */
    private static createHostRule(ruleText: string, filterListId: number, ruleIndex: number): HostRule | null {
        const rule = new HostRule(ruleText, filterListId, ruleIndex);
        return rule.isInvalid() ? null : rule;
    }

    /**
     * Checks if rule is short
     */
    public static isShort(rule: string): boolean {
        if (!rule) {
            return true;
        }
        return !!(rule && rule.length <= 3);
    }

    /**
     * Checks if the rule is cosmetic or not.
     * @param ruleText - rule text to check.
     */
    public static isCosmetic(ruleText: string): boolean {
        const marker = findCosmeticRuleMarker(ruleText);
        return marker[0] !== -1;
    }

    /**
     * If text is comment
     *
     * @param text
     */
    public static isComment(text: string): boolean {
        const trimmed = text.trim();

        if (trimmed.charAt(0) === '!') {
            return true;
        }

        // adblock agent
        if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
            // avoid this case: [$adg=modifier]##[css-attribute=selector]
            return !RuleFactory.isCosmetic(text);
        }

        // host-like / uBO-like comment
        if (text.charAt(0) === '#') {
            if (text.length === 1) {
                return true;
            }

            // Now we should check that this is not a cosmetic rule
            return !RuleFactory.isCosmetic(text);
        }

        return false;
    }
}
