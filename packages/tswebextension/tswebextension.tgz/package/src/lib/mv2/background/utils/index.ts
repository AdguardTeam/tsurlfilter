export * from './browser-detector';
