import { redirects } from '@adguard/scriptlets';
import type { Redirect, Redirects } from '@adguard/scriptlets';
import type { ResourcesService } from '../resources-service';

import { redirectsCache } from './redirects-cache';
import { redirectsTokensCache } from './redirects-tokens-cache';
import { logger } from '../../../../common';
import { isFirefox } from '../../utils';

const BASE_64 = 'base64';
const CONTENT_TYPE_SEPARATOR = ';';

/**
 * Service for working with redirects.
 */
export class RedirectsService {
    redirects: Redirects | null = null;

    /**
     * Cache for encoded redirects.
     */
    dataUrlCache: Map<string, string> = new Map();

    /**
     * Creates {@link RedirectsService} instance.
     * @param resourcesService Prevent web pages to identify extension through its web accessible resources.
     */
    constructor(
        private readonly resourcesService: ResourcesService,
    ) {}

    /**
     * Starts redirects service.
     */
    public async start(): Promise<void> {
        try {
            const rawYaml = await this.resourcesService.loadResource('redirects.yml');

            this.redirects = new redirects.Redirects(rawYaml);
        } catch (e) {
            throw new Error((e as Error).message);
        }
    }

    /**
     * Checks whether content type is base64 encoded.
     *
     * @param contentType Content type.
     * @returns True if content type is base64 encoded.
     */
    private static isBase64EncodedContentType = (contentType: string): boolean => {
        return contentType.endsWith(BASE_64);
    };

    /**
     * Creates data url for the specified redirect. It caches created urls.
     *
     * @param redirect Redirect.
     * @returns Data URL.
     * @see https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URLs
     */
    private createRedirectDataUrl(redirect: Redirect): string {
        let url = this.dataUrlCache.get(redirect.title);

        if (url) {
            return url;
        }

        let { contentType, content } = redirect;

        if (!RedirectsService.isBase64EncodedContentType(contentType)) {
            contentType += CONTENT_TYPE_SEPARATOR + BASE_64;
            content = btoa(content);
        }

        url = `data:${contentType},${content}`;
        this.dataUrlCache.set(redirect.title, url);

        return url;
    }

    /**
     * Returns redirect url for the specified title.
     *
     * @param title Redirect title or null.
     * @param requestUrl Request url.
     * @returns Redirect url or null if redirect is not found.
     */
    public createRedirectUrl(title: string | null, requestUrl: string): string | null {
        if (!title) {
            return null;
        }

        if (!this.redirects) {
            return null;
        }

        const redirectSource = this.redirects.getRedirect(title);

        if (!redirectSource) {
            logger.debug(`There is no redirect source with title: "${title}"`);
            return null;
        }

        const shouldRedirect = this.shouldCreateRedirectUrl(title, requestUrl);
        if (!shouldRedirect) {
            return null;
        }

        if (redirectSource.isBlocking) {
            // For blocking redirects we generate additional search params.
            const params = this.blockingUrlParams(title, requestUrl);
            // TODO: 'redirects/' should be moved to extension part
            return this.resourcesService.createResourceUrl(`redirects/${redirectSource.file}`, params);
        }

        if (isFirefox) {
            // Firefox throws same origin policy error when trying to load redirect resource from data url,
            // so we use the old way to load redirect resources.
            // https://bugzilla.mozilla.org/show_bug.cgi?id=1016491
            // https://www.rfc-editor.org/rfc/rfc6454#section-5
            return this.resourcesService.createResourceUrl(`redirects/${redirectSource.file}`);
        }

        return this.createRedirectDataUrl(redirectSource);
    }

    /**
     * Check whether redirect creating is needed i.e.: for click2load.html it's not needed after
     * button click.
     *
     * @param redirectTitle A name of the redirect.
     * @param requestUrl Request url.
     * @returns True if should create redirect url.
     */
    private shouldCreateRedirectUrl = (redirectTitle: string, requestUrl: string): boolean => {
        // if no redirects loaded we won't be able to create redirect url;
        if (!this.redirects) {
            return false;
        }

        // no further checking is needed for most of the redirects
        // except blocking redirects, i.e. click2load.html
        if (!this.redirects.isBlocking(redirectTitle)) {
            return true;
        }

        // unblock token passed to redirect by createRedirectFileUrl and returned back.
        // it should be last parameter in url
        const UNBLOCK_TOKEN_PARAM = '__unblock';
        let cleanRequestUrl = requestUrl;
        const url = new URL(requestUrl);
        const params = new URLSearchParams(url.search);
        const unblockToken = params.get(UNBLOCK_TOKEN_PARAM);
        if (unblockToken) {
            // if redirect has returned unblock token back,
            // add url to cache for no further redirecting on button click;
            // save cleaned origin url so unblock token parameter should be cut off
            params.delete(UNBLOCK_TOKEN_PARAM);
            cleanRequestUrl = `${url.origin}${url.pathname}?${params.toString()}`;
            redirectsCache.add(cleanRequestUrl);
        }
        return !redirectsCache.hasUrl(cleanRequestUrl)
            || !redirectsTokensCache.hasToken(unblockToken);
    };

    /**
     * Builds blocking url search params.
     *
     * @param redirectTitle Title of the redirect.
     * @param requestUrl Request url.
     * @throws Error if this method called before redirects where set.
     * @returns Url search params.
     * @private
     */
    private blockingUrlParams(redirectTitle: string, requestUrl: string): URLSearchParams {
        if (!this.redirects) {
            throw new Error('This method should be called after redirects are loaded');
        }

        const params = new URLSearchParams();
        if (this.redirects.isBlocking(redirectTitle)) {
            const unblockToken = redirectsTokensCache.generateToken();
            params.set('__unblock', unblockToken);
            params.set('__origin', requestUrl);
        }
        return params;
    }
}
